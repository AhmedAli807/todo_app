import 'package:flutter/material.dart';

class Constants extends StatefulWidget {
  const Constants({Key? key}) : super(key: key);

  @override
  State<Constants> createState() => _ConstantsState();
}

class _ConstantsState extends State<Constants> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
